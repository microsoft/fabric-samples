import duckdb
import pandas as pd
import pyarrow as pa
from azure.identity import AuthenticationRequiredError, ClientSecretCredential, InteractiveBrowserCredential
from deltalake import DeltaTable
from deltalake.writer import write_deltalake

from ..core import EntityRelationship, EntityType, EntityTypeProperty, Ontology
from .clientconfig import ClientConfig


class AlpineLakesClient:

    config: ClientConfig
    lakehouse_name: str
    tmp_entity_types_table_name: str
    tmp_entity_properties_table_name: str
    tmp_entity_relationships_table_name: str

    def __init__(self, config: ClientConfig):
        self.config = config
        self.tmp_entity_types_table_name = "tmp_entitytypes"
        self.tmp_entity_properties_table_name = "tmp_entityproperties"
        self.tmp_entity_relationships_table_name = "tmp_entityrelationships"
        self.lakehouse_name = config.item_name + "dtdm"

    def get_database_name(self) -> str:
        return self.lakehouse_name

    def get_temp_ontology(self, namespace: str, storage_options: dict) -> Ontology:
        where_clause = f"where namespace = '{namespace}'"
        df_types = self.__read_delta_table(self.tmp_entity_types_table_name, storage_options, where_clause)
        df_properties = self.__read_delta_table(self.tmp_entity_properties_table_name, storage_options, where_clause)
        df_relationships = self.__read_delta_table(
            self.tmp_entity_relationships_table_name, storage_options, where_clause
        )

        types = [EntityType(**x) for x in df_types.to_dict(orient="records")]
        properties = [EntityTypeProperty(**x) for x in df_properties.to_dict(orient="records")]
        relationships = [EntityRelationship(**x) for x in df_relationships.to_dict(orient="records")]

        return Ontology(namespace, types, properties, relationships)

    def save_temp_ontology(self, ontology: Ontology, storage_options: dict) -> None:
        df_types = pd.DataFrame([x.as_dict() for x in ontology.types], index=None)
        df_properties = pd.DataFrame([x.as_dict() for x in ontology.properties], index=None)
        df_relationships = pd.DataFrame([x.as_dict() for x in ontology.relationships], index=None)

        # TODO: Add Upsert logic
        self.__append_delta_table(self.tmp_entity_types_table_name, df_types, storage_options)
        self.__append_delta_table(self.tmp_entity_properties_table_name, df_properties, storage_options)
        self.__append_delta_table(self.tmp_entity_relationships_table_name, df_relationships, storage_options)

    def __read_delta_table(self, table_name: str, storage_options: dict, where_clause: str = None) -> pd.DataFrame:
        try:
            full_path = "/".join([self.config.lakehouse_absf_path, "Tables", table_name])
            current_table = DeltaTable(full_path, storage_options=storage_options).to_pyarrow_dataset()
            return duckdb.sql(f"select * from current_table {where_clause}").df()  # need to add limit to control egress
        except Exception as e:
            raise e

    def __append_delta_table(self, table_name: str, data: pd.DataFrame, storage_options: dict):
        full_path = "/".join([self.config.lakehouse_absf_path, "Tables", table_name])
        parrow_table = pa.Table.from_pandas(data)
        write_deltalake(full_path, parrow_table, mode="append", storage_options=storage_options)

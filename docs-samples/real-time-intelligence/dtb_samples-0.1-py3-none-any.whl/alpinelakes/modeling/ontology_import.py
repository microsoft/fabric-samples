import json
import xml.etree.ElementTree as ET

from rdflib import OWL, RDF, RDFS, Graph, URIRef

from ..client import AlpineLakesClient

# Replace these imports with wherever you defined them
from ..core import EntityRelationship, EntityType, EntityTypeProperty, Ontology
from ..utilities import rdf_utilities
from .dtdl_import import DTDLImport
from .opcua_import import OPCUAImport
from .openusd_import import OpenUSDImport


class OntologyImport:
    client: AlpineLakesClient

    def __init__(self, client: AlpineLakesClient):
        self.client = client

    def from_rdf(self, namespace: str, rdf_file_content: str, rdf_format: str = "turtle") -> Ontology:
        """
        Builds an Ontology object from RDF content.

        :param namespace: The default ontology namespace.
        :param rdf_file_content: Content of the RDF (.ttl, .rdf, etc.) file.
        :param rdf_format: RDF format for parsing ('turtle', 'xml', 'n3', 'nt', ...).

        :return: Ontology object
        """
        # -----------------------------
        # 0) Initialize the graph
        # -----------------------------
        graph = Graph()
        # For really large ontologies, consider using a triple-store or endpoint instead of a local parse
        graph.parse(data=rdf_file_content, format=rdf_format)
        print(f"Graph loaded with {len(graph)} triples.")

        # -----------------------------
        # 1) Prepare data structures
        # -----------------------------
        ontology = Ontology(namespace=namespace)  # Our object-oriented container

        # For analytics-friendly output
        types_data = []  # Will hold class-level info
        properties_data = []  # Will hold property info
        relationships_data = []  # Will hold relationship info

        # -----------------------------
        # 2) Extract Classes (OWL.Class)
        # -----------------------------
        for s in graph.subjects(RDF.type, OWL.Class):
            class_id = str(s)
            class_name = rdf_utilities.extract_rdf_label(graph, s)
            class_description = rdf_utilities.extract_rdf_comment(graph, s)

            # Populate Ontology
            entity_type = EntityType(
                id=class_id,
                name=class_name if class_name else class_id,
                description=class_description if class_description else "",
            )
            ontology.add_entity_type(entity_type)

            # Prepare row for DataFrame
            types_data.append(
                {
                    "class_id": class_id,
                    "class_name": class_name or class_id,
                    "class_description": class_description or "",
                    "namespace": namespace,
                }
            )

        # -----------------------------
        # 3) Extract Object Properties (OWL.ObjectProperty)
        #    - They can be both relationships (domain->range) and properties
        # -----------------------------
        for p in graph.subjects(RDF.type, OWL.ObjectProperty):
            prop_id = str(p)
            prop_name = self.__extract_rdf_label(graph, p)
            prop_description = self.__extract_rdf_comment(graph, p)

            domain_list = list(graph.objects(p, RDFS.domain))
            range_list = list(graph.objects(p, RDFS.range))

            # Relationship if domain and range exist
            if domain_list and range_list:
                relationship = EntityRelationship(
                    name=prop_name if prop_name else prop_id,
                    source=str(domain_list[0]),
                    target=str(range_list[0]),
                )
                ontology.add_entity_relationship(relationship)
                # For DataFrame, we'll create one row per domain-range pairing (most common is just 1-1).
                for dom, ran in zip(domain_list, range_list):
                    relationships_data.append(
                        {
                            "relationship_id": prop_id,
                            "relationship_name": prop_name or prop_id,
                            "source": str(dom),
                            "target": str(ran),
                            "description": prop_description or "",
                            "namespace": namespace,
                        }
                    )

            # As a property
            entity_property = EntityTypeProperty(
                id=prop_id,
                name=prop_name if prop_name else prop_id,
                description=prop_description if prop_description else "",
                datatype="object",  # For object properties
                entitytypeid=str(domain_list[0]) if domain_list else "",
            )
            ontology.add_entity_property(entity_property)

            # For DataFrame
            # If there are multiple domain classes, we can create multiple rows
            # (Same for multiple range classes, though uncommon)
            if not domain_list:
                # If no domain, store empty or some placeholder
                domain_list = [URIRef("NoDomain")]
            for dom in domain_list:
                properties_data.append(
                    {
                        "property_id": prop_id,
                        "property_name": prop_name or prop_id,
                        "property_description": prop_description or "",
                        "datatype": "object",
                        "entity_type_id": str(dom),
                        "namespace": namespace,
                    }
                )

        # -----------------------------
        # 4) Extract Datatype Properties (OWL.DatatypeProperty)
        # -----------------------------
        for p in graph.subjects(RDF.type, OWL.DatatypeProperty):
            prop_id = str(p)
            prop_name = self.__extract_rdf_label(graph, p)
            prop_description = self.__extract_rdf_comment(graph, p)

            domain_list = list(graph.objects(p, RDFS.domain))
            range_list = list(graph.objects(p, RDFS.range))
            # If no range found, default to "string"
            data_type = str(range_list[0]) if range_list else "string"

            entity_property = EntityTypeProperty(
                id=prop_id,
                name=prop_name if prop_name else prop_id,
                description=prop_description if prop_description else "",
                datatype=data_type,
                entitytypeid=str(domain_list[0]) if domain_list else "",
            )
            ontology.add_entity_property(entity_property)

            if not domain_list:
                domain_list = [URIRef("NoDomain")]
            for dom in domain_list:
                properties_data.append(
                    {
                        "property_id": prop_id,
                        "property_name": prop_name or prop_id,
                        "property_description": prop_description or "",
                        "datatype": data_type,
                        "entity_type_id": str(dom),
                        "namespace": namespace,
                    }
                )

        # -----------------------------
        # 5) Return result
        # -----------------------------
        return ontology

    def from_opcua_xml(self, xml_file_content: str) -> Ontology:
        return OPCUAImport().generate_ontology(xml_file_content)
    def from_opcua_xml_multiple(self, xml_file_content: str, namespace_files: dict = None) -> list:
        return OPCUAImport().generate_ontologies(xml_file_content, namespace_files)

    def from_dtdl(self, namespace: str, dtdl_file_content: str) -> Ontology:
        return DTDLImport().generate_ontology(namespace, dtdl_file_content)

    def from_openusd(self, namespace: str, openusd_file_content: str) -> Ontology:
        return OpenUSDImport().generate_ontology(namespace, openusd_file_content)

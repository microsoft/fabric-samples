from ..core import EntityRelationship, EntityType, EntityTypeProperty, Ontology


class OpenUSDImport:

    def generate_ontology(namespace: str, openusd_file_content: str) -> Ontology:

        ontology = Ontology(namespace)

        # TODO -> Need to implement

        return ontology

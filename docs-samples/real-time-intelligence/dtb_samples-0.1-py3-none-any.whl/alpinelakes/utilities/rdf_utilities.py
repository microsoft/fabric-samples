from typing import Optional

from rdflib import OWL, RDFS, Graph, Literal, URIRef


def extract_rdf_label(graph: Graph, resource: URIRef) -> Optional[str]:
    """
    Helper function to extract rdfs:label if available.
    """
    label_list = list(graph.objects(resource, RDFS.label))
    if label_list and isinstance(label_list[0], Literal):
        return str(label_list[0])
    return None


def extract_rdf_comment(graph: Graph, resource: URIRef) -> Optional[str]:
    """
    Helper function to extract rdfs:comment or owl:comment if available.
    """
    # Try rdfs:comment first
    comment_list = list(graph.objects(resource, RDFS.comment))
    if not comment_list:
        # Then owl:comment
        comment_list = list(graph.objects(resource, OWL.comment))
    if comment_list and isinstance(comment_list[0], Literal):
        return str(comment_list[0])
    return None

from typing import List, Optional

from pyspark.sql import DataFrameReader, SparkSession

from ..client import AlpineLakesClient
from ..core import (
    EntityInstance,
    EntityInstanceTimeSeries,
    EntityRelationship,
    EntityRelationshipInstance,
    EntityType,
    EntityTypeProperty,
    Ontology,
)


class AlpineLakesEventhouseHelper:
    client: AlpineLakesClient

    kql_function_name_token = "#function_name#"
    kql_function_entitytypeid_token = "#function_entitytypeid#"
    kql_function_columns_token = "#function_columns#"
    kql_property_function_template = """.create-or-alter function #function_name# () {
        let entity_property = (
            external_table("propertydescriptor")
            | where EntityTypeId == '#function_entitytypeid#'
            | project PropertyDescriptorId = Id, Name, ValueTypeId
            | join kind=leftouter (
                (external_table("stringpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, StringValue = Value)
                | union (external_table("boolpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, BoolValue = Value)
                | union (external_table("bigintpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, BigIntValue = Value)
                | union (external_table("doublepropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, DoubleValue = Value)
                | union (external_table("floatpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, FloatValue = Value)
                | union (external_table("datetimepropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, DateTimeValue = Value)
            ) on PropertyDescriptorId
            | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, Name, StringValue, BoolValue, BigIntValue, DoubleValue, FloatValue, DateTimeValue
            | where isnotnull(EntityInstanceId1) and isnotnull(EntityInstanceId2)
            | summarize
                #function_columns#
        );
        entity_property
        }
    """

    kql_ts_function_template = """.create-or-alter function #function_name# () {
        let Timeseries_property = (
            external_table("timeseriespropertydescriptor")
            | where EntityTypeId == '#function_entitytypeid#'
            | project TimeseriesPropertyDescriptorId = Id, Name, ValueTypeId
            | join kind=inner (
                external_table("timeseriesinstancedescriptor")
                | project Id1, Id2, EntityInstanceId1, EntityInstanceId2, TimeseriesPropertyDescriptorId
            ) on $left.TimeseriesPropertyDescriptorId == $right.TimeseriesPropertyDescriptorId
            | join kind=leftouter (
                (external_table("stringtimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, StringValue = Value)
                | union (external_table("booltimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, BoolValue = Value)
                | union (external_table("biginttimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, BigIntValue = Value)
                | union (external_table("floattimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, FloatValue = Value)
                | union (external_table("doubletimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, DoubleValue = Value)
                | union (external_table("datetimetimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, DateTimeValue = Value)
            ) on $left.Id1 == $right.TimeseriesInstanceDescriptorId1 and $left.Id2 == $right.TimeseriesInstanceDescriptorId2
            | project EntityInstanceId1, EntityInstanceId2, PreciseTimestamp, Name, StringValue, BoolValue, BigIntValue, DoubleValue, FloatValue, DateTimeValue
            | where isnotnull(EntityInstanceId1) and isnotnull(EntityInstanceId2)
            | summarize
                #function_columns#
        );
        Timeseries_property
        }
    """

    kql_shortcut_table_name_token = "#table_name#"
    kql_shortcut_base_path_token = "#base_path#"
    kql_create_shortcut_template = """.create external table #table_name#
    kind=delta
    (  
        h@'#base_path#.Lakehouse/Tables/#table_name#;impersonate'
    )
    //.alter external table #table_name# policy query_acceleration '{ "IsEnabled": true, "Hot": "36500d" }'
    """

    def __init__(self, client: AlpineLakesClient):
        self.client = client

    def generate_eventhouse_projection(
        self, current_ontology_lh_name: str, spark: SparkSession, df_reader: DataFrameReader
    ) -> str:

        df_types = (
            spark.read.synapsesql(f"{current_ontology_lh_name}.dbo.entitytype")
            .filter("BaseEntityTypeId != 0")
            .withColumnRenamed("Name", "EntityTypeName")
        )

        df_views_schema = df_reader.synapsesql(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_SCHEMA = 'dom'"
        )
        views_schema_list = df_views_schema.rdd.map(lambda x: x[0]).collect()
        # print(views_schema_list)

        file_content = """
        .execute database script with (ContinueOnErrors=true)
        <|
        """

        file_content += self.__generate_shorcuts(df_reader, current_ontology_lh_name, self.client.config.workspace_name)

        file_content += self.__generate_property_function(
            df_reader, current_ontology_lh_name, df_types, views_schema_list
        )

        file_content += self.__generate_ts_property_function(
            df_reader, current_ontology_lh_name, df_types, views_schema_list
        )

        return file_content

    def __generate_property_function(self, df_reader, current_ontology_lh_name, df_types, views_schema_list) -> str:
        file_content = ""
        for type_row in df_types.rdd.toLocalIterator():
            entity_function_name = type_row["EntityTypeName"] + "_property"
            if entity_function_name not in views_schema_list:
                continue

            entity_type_id = type_row["Id"]

            property_query = (
                f"SELECT pd.EntityTypeId, pd.Name, vt.ValueType + 'Value' as ValueType FROM [{current_ontology_lh_name}].[dbo].[propertydescriptor] as pd "
                f"INNER JOIN [{current_ontology_lh_name}].[dbo].[valuetype] as vt on pd.ValueTypeId = vt.Id "
                f"WHERE EntityTypeId = '{entity_type_id}'"
            )

            df_property = df_reader.synapsesql(property_query)
            function_column_text = ""
            for property_row in df_property.rdd.toLocalIterator():
                function_column_text += (
                    f'{property_row["Name"]} = minif({property_row["ValueType"]}, Name == "{property_row["Name"]}"),'
                )

            function_column_text = function_column_text[:-1]
            function_column_text += " by EntityInstanceId1, EntityInstanceId2 "
            function_text = (
                self.kql_property_function_template.replace(self.kql_function_name_token, entity_function_name)
                .replace(self.kql_function_entitytypeid_token, str(entity_type_id))
                .replace(self.kql_function_columns_token, function_column_text)
            )
            file_content += function_text
            print(f"Added function - {entity_function_name}")

        return file_content

    def __generate_ts_property_function(self, df_reader, current_ontology_lh_name, df_types, views_schema_list) -> str:
        file_content = ""
        for type_row in df_types.rdd.toLocalIterator():
            entity_function_name = type_row["EntityTypeName"] + "_timeseries"
            if entity_function_name not in views_schema_list:
                continue

            entity_type_id = type_row["Id"]

            ts_property_query = (
                f"SELECT pd.EntityTypeId, pd.Name, vt.ValueType + 'Value' as ValueType FROM [{current_ontology_lh_name}].[dbo].[timeseriespropertydescriptor] as pd "
                f"INNER JOIN [{current_ontology_lh_name}].[dbo].[valuetype] as vt on pd.ValueTypeId = vt.Id "
                f"WHERE EntityTypeId = '{entity_type_id}' AND pd.Name != 'Timestamp'"
            )

            df_property = df_reader.synapsesql(ts_property_query)
            function_column_text = ""
            for property_row in df_property.rdd.toLocalIterator():
                function_column_text += (
                    f'{property_row["Name"]} = minif({property_row["ValueType"]}, Name == "{property_row["Name"]}"),'
                )

            function_column_text = function_column_text[:-1]
            function_column_text += " by EntityInstanceId1, EntityInstanceId2, PreciseTimestamp "
            function_text = (
                self.kql_ts_function_template.replace(self.kql_function_name_token, entity_function_name)
                .replace(self.kql_function_entitytypeid_token, str(entity_type_id))
                .replace(self.kql_function_columns_token, function_column_text)
            )
            file_content += function_text
            print(f"Added function - {entity_function_name}")

        return file_content

    def __generate_shorcuts(self, df_reader, current_ontology_lh_name, workspace_name) -> str:
        file_content = ""
        df_table_schema = df_reader.synapsesql(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo'"
        )
        table_list = df_table_schema.rdd.map(lambda x: x[0]).collect()

        base_path = f"abfss://{workspace_name}@dxt-onelake.dfs.fabric.microsoft.com/{current_ontology_lh_name}"

        table_text = ""
        for table in table_list:
            # print(table)
            table_text += self.kql_create_shortcut_template.replace(self.kql_shortcut_table_name_token, table).replace(
                self.kql_shortcut_base_path_token, base_path
            )
        file_content += table_text
        return file_content

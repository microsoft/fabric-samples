import matplotlib.pyplot as plt
import networkx as nx


class SemanticGraph:
    def __init__(self, graphName):
        self.graph = nx.MultiDiGraph(name=graphName)
        self.is_temporal = False

    def add_node(self, node_id, **attributes):
        self.graph.add_node(node_id, **attributes)

    def add_edge(self, from_node, to_node, **attributes):
        self.graph.add_edge(from_node, to_node, **attributes)

    def update_node(self, node_id, **attributes):
        for attr, value in attributes.items():
            self.graph.nodes[node_id][attr] = value

    def get_node_attributes(self, node_id):
        return self.graph.nodes[node_id]

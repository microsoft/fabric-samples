from datetime import datetime  # noqa F401
from typing import Optional


class EntityInstance:
    entity_type_name: str
    entity_instance_id: str
    entity_instance_name: str
    properties: dict

    def __init__(self, entity_type_name: str, entity_instance_id: str, entity_instance_name: str, properties: dict):
        self.entity_type_name = entity_type_name
        self.entity_instance_id = entity_instance_id
        self.entity_instance_name = entity_instance_name
        self.properties = properties

    def as_dict(self):
        return {
            "entity_type_name": self.entity_type_name,
            "entity_instance_id": self.entity_instance_id,
            "entity_instance_name": self.entity_instance_name,
            "properties": self.properties,
        }

from typing import List, Optional

import pandas as pd
import pyarrow as pa

from .entity_instance import EntityInstance
from .entity_instance_timesseries import EntityInstanceTimeSeries
from .entity_relationship import EntityRelationship
from .entity_relationship_instance import EntityRelationshipInstance
from .entity_type import EntityType
from .entity_type_property import EntityTypeProperty


class Ontology:
    namespace: str
    types: List[EntityType]
    properties: List[EntityTypeProperty]
    relationships: List[EntityRelationship]
    instances: List[EntityInstance]
    instances_time_series: List[EntityInstanceTimeSeries]
    relationship_instances: List[EntityRelationshipInstance]

    def __init__(
        self,
        namespace: str,
        types: Optional[List[EntityType]] = None,
        properties: Optional[List[EntityTypeProperty]] = None,
        relationships: Optional[List[EntityRelationship]] = None,
        instances: Optional[List[EntityInstance]] = None,
        instances_time_series: Optional[List[EntityInstanceTimeSeries]] = None,
        relationship_instances: Optional[List[EntityRelationshipInstance]] = None,
    ):
        self.namespace = namespace
        self.types = types if types else []
        self.properties = properties if properties else []
        self.relationships = relationships if relationships else []
        self.instances = instances if instances else []
        self.instances_time_series = instances_time_series if instances_time_series else []
        self.relationship_instances = relationship_instances if relationship_instances else []

    def add_entity_type(self, entity_type: EntityType) -> None:
        entity_type.namespace = self.namespace
        filtered_types = [et for et in self.types if et.name == entity_type.name]
        if not filtered_types:
            self.types.append(entity_type)

    def add_entity_property(self, entity_property: EntityTypeProperty) -> None:
        entity_property.namespace = self.namespace
        self.properties.append(entity_property)

    def add_entity_relationship(self, entity_relationship: EntityRelationship) -> None:
        entity_relationship.namespace = self.namespace
        self.relationships.append(entity_relationship)

    def add_entity_instance(self, entity_instance: EntityInstance) -> None:
        entity_instance.namespace = self.namespace
        self.instances.append(entity_instance)

    def add_entity_instance_time_series(self, entity_instance_time_series: EntityInstanceTimeSeries) -> None:
        entity_instance_time_series.namespace = self.namespace
        self.instances_time_series.append(entity_instance_time_series)

    def add_entity_instance_time_series_list(
        self, entity_instance_time_series_list: List[EntityInstanceTimeSeries]
    ) -> None:
        self.instances_time_series.extend(entity_instance_time_series_list)

    def add_entity_relationship_instance(self, relationship_instance: EntityRelationshipInstance) -> None:
        self.relationship_instances.append(relationship_instance)

    def add_entity_relationship_instances(self, relationship_instances: List[EntityRelationshipInstance]) -> None:
        source_names = {instance.entity_instance_name for instance in self.instances}
        target_names = {instance.entity_instance_name for instance in self.instances}

        # Use list comprehension instead of loop for fast filtering
        valid_relationships = [
            instance
            for instance in relationship_instances
            if instance.source_entity_instance_name in source_names
            and instance.target_entity_instance_name in target_names
        ]

        # Bulk insert
        self.relationship_instances.extend(valid_relationships)

    def get_entity_type_by_name(self, name: str) -> EntityType:
        filtered_types = [et for et in self.types if et.name == name]
        if not filtered_types:
            raise ValueError(f"Entity type '{name}' not found in ontology.")
        return filtered_types[0]

    def get_relationship_type(self, source_entity_name: str, target_entity_name: str) -> Optional[str]:
        for relationship in self.relationships:
            if relationship.source == source_entity_name and relationship.target == target_entity_name:
                return relationship.name
        return None

    def get_entity_instances_by_type(self, entity_type_name: str):
        return [instance for instance in self.instances if instance.entity_type_name == entity_type_name]

    def get_properties_by_entity_type(self, entity_type_name: str) -> List[EntityTypeProperty]:
        entity_type = self.get_entity_type_by_name(entity_type_name)
        return [prop for prop in self.properties if prop.entitytypeid == entity_type.id]

from typing import Optional


class EntityTypeProperty:
    id: str
    name: str
    namespace: str
    description: str
    datatype: str
    entitytypeid: str
    entitytypename: str  # TODO need to refactor code to use this

    def __init__(
        self,
        id: str,
        name: str,
        description: str,
        datatype: str,
        entitytypeid: str,
        namespace: Optional[str] = "",
        entitytypename: Optional[str] = "",
    ):
        self.id = id
        self.name = name
        self.description = description
        self.datatype = datatype
        self.entitytypeid = entitytypeid
        self.namespace = namespace
        self.entitytypename = entitytypename

    def as_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "namespace": self.namespace,
            "description": self.description,
            "datatype": self.datatype,
            "entitytypeid": self.entitytypeid,
            "entitytypename": self.entitytypename,
        }

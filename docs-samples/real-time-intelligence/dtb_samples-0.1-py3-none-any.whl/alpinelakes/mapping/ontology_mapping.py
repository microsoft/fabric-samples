from typing import List, Optional

import pandas as pd

from ..client import AlpineLakesClient
from ..core.entity_instance import EntityInstance
from ..core.entity_relationship_instance import EntityRelationshipInstance
from ..core.ontology import Ontology
from .entity_mapping_config import EntityMappingConfig
from .relationship_mapping_config import RelationshipMappingConfig
from pyspark.sql import SparkSession


class OntologyMapping:
    client: AlpineLakesClient
    ontology: Ontology
    entity_mappings: List[EntityMappingConfig]
    relationship_mappings: List[RelationshipMappingConfig]

    def __init__(self, ontology: Ontology, client: AlpineLakesClient):
        self.client = client
        self.ontology = ontology
        self.entity_mappings = []
        self.relationship_mappings = []

    def add_entity_mapping(self, mapping_config: EntityMappingConfig):
        self.entity_mappings.append(mapping_config)

    def add_relationship_mapping(self, relationship_mapping_config: RelationshipMappingConfig):
        self.relationship_mappings.append(relationship_mapping_config)

    def run(self, mapping_config):
        if isinstance(mapping_config, EntityMappingConfig):
            self.__map_entities(mapping_config)
        elif isinstance(mapping_config, RelationshipMappingConfig):
            self.__map_relationships(mapping_config)
        else:
            raise ValueError("Unsupported mapping configuration type")

    def __map_entities(self, entity_mapping_config: EntityMappingConfig):
        properties = self.ontology.get_properties_by_entity_type(entity_mapping_config.entity_type_name)

        for target_property in entity_mapping_config.target_source_properties.keys():
            property_found = next((prop for prop in properties if prop.name == target_property), None)
            if property_found is None:
                raise ValueError(
                    f"Property '{target_property}' not found in entity type {entity_mapping_config.entity_type_name}"
                )

        # For each row in the source data, create an EntityInstance object
        for index, row in entity_mapping_config.source_data.iterrows():
            entity_instance = EntityInstance(
                entity_type_name=entity_mapping_config.entity_type_name,
                entity_instance_id=row[entity_mapping_config.id_property],
                entity_instance_name=row[entity_mapping_config.id_property],
                properties={
                    target_property: row[source_property]
                    for target_property, source_property in entity_mapping_config.target_source_properties.items()
                    if source_property != entity_mapping_config.id_property
                },
            )
            # Add the created EntityInstance object to the ontology
            self.ontology.add_entity_instance(entity_instance)

    def __map_relationships(self, relationship_mapping_config: RelationshipMappingConfig):
        source_entity_name = relationship_mapping_config.source_entity_name
        target_entity_name = relationship_mapping_config.target_entity_name
        source_entity_property = relationship_mapping_config.source_entity_property
        target_entity_property = relationship_mapping_config.target_entity_property

        relationship_type_name = self.ontology.get_relationship_type(source_entity_name, target_entity_name)
        if relationship_type_name is None:
            raise ValueError(f"No relationship type found between '{source_entity_name}' and '{target_entity_name}' in the ontology.")

        source_instances = self.ontology.get_entity_instances_by_type(source_entity_name)
        target_instances = self.ontology.get_entity_instances_by_type(target_entity_name)

        if not source_instances or not target_instances:
            return

        # 🚀 Use active Spark session
        spark = SparkSession.getActiveSession()

        # ✅ Convert entity instances into Spark DataFrame
        source_df = spark.createDataFrame([
            (instance.entity_instance_name, instance.properties.get(source_entity_property))
            for instance in source_instances if source_entity_property in instance.properties
        ], ["source_name", "match_value"])

        target_df = spark.createDataFrame([
            (instance.entity_instance_name, instance.properties.get(target_entity_property))
            for instance in target_instances if target_entity_property in instance.properties
        ], ["target_name", "match_value"])

        if source_df.count() == 0 or target_df.count() == 0:
            return

        # ✅ Optimized Spark join for relationship mapping
        joined_df = source_df.join(target_df, "match_value").select("source_name", "target_name")

        # ✅ Collect structured data in memory (avoid creating objects in Spark workers)
        collected_relationships = joined_df.collect()

        # ✅ Process relationships in memory (on the driver)
        relationship_instances = [
            EntityRelationshipInstance(
                relationship_type_name=relationship_type_name,
                source_entity_instance_name=row["source_name"],
                target_entity_instance_name=row["target_name"]
            )
            for row in collected_relationships
        ]

        # ✅ Bulk insert relationships
        self.ontology.add_entity_relationship_instances(relationship_instances)

    def create_entity_relationship_instances(
        self,
        source_entity_name: str,
        target_entity_name: str,
        relationship_type_name: str,
        source_data: pd.DataFrame,
        source_entity_property: str,
        target_entity_property: str,
    ):
        source_instances = self.ontology.get_entity_instances_by_type(source_entity_name)
        target_instances = self.ontology.get_entity_instances_by_type(target_entity_name)

        source_instance_dict = {instance.entity_instance_name: instance for instance in source_instances}
        target_instance_dict = {instance.entity_instance_name: instance for instance in target_instances}

        for index, row in source_data.iterrows():
            source_instance_name = row[source_entity_property]
            target_instance_name = row[target_entity_property]

            if source_instance_name in source_instance_dict and target_instance_name in target_instance_dict:
                relationship_instance = EntityRelationshipInstance(
                    relationship_type_name=relationship_type_name,
                    source_entity_instance_name=source_instance_name,
                    target_entity_instance_name=target_instance_name,
                )
                self.ontology.add_entity_relationship_instance(relationship_instance)

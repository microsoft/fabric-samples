import pandas as pd


class EntityMappingConfig:
    entity_type_name: str
    entity_name: str
    source_data: pd.DataFrame
    target_source_properties: dict
    id_property: str
    

    def __init__(
        self, entity_type_name: str, entity_name: str, target_source_properties: dict, source_data: pd.DataFrame, id_property: str
    ):
        self.entity_type_name = entity_type_name
        self.entity_name = entity_name
        self.target_source_properties = target_source_properties
        self.source_data = source_data
        self.id_property = id_property
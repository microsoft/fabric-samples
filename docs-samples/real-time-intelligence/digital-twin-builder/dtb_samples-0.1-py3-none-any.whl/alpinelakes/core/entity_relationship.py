from typing import Optional


class EntityRelationship:
    name: str
    namespace: str
    source: str
    target: str
    attributes: str

    def __init__(self, name: str, source: str, target: str, namespace: Optional[str] = ""):
        self.name = name
        self.source = source
        self.target = target
        self.namespace = namespace

    def as_dict(self):
        return {"name": self.name, "namespace": self.namespace, "source": self.source, "target": self.target}

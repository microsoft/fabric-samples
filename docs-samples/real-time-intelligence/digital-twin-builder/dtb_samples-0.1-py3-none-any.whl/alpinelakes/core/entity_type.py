from typing import Optional

class EntityType:
    id:str
    namespace:str
    name:str
    description:str
    isreadonly:bool
    parententitytypeid:str

    def __init__(self, id:str, name:str, description:str,
                 namespace:Optional[str]= "",
                 isreadonly:Optional[bool] = False, 
                 parententitytypeid:Optional[str] = ""):
        self.id = id
        self.name = name
        self.description = description
        self.isreadonly = isreadonly
        self.parententitytypeid = parententitytypeid
        self.namespace = namespace

    def as_dict(self):
        return {"id": self.id, "name": self.name, "namespace": self.namespace,
                "description": self.description, "parententitytypeid": self.parententitytypeid,
                "isreadonly": self.isreadonly}    
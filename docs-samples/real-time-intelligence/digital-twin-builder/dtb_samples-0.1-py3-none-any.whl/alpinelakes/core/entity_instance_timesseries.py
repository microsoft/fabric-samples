from datetime import datetime  # noqa F401
from typing import Optional


class EntityInstanceTimeSeries:
    entity_type_name: str
    entity_instance_id: str
    entity_instance_name: str
    ts_property_name: str
    ts_property_value: float
    timestamp: datetime
    properties: dict

    def __init__(
        self,
        entity_type_name: str,
        entity_instance_id: str,
        entity_instance_name: str,
        ts_property_name: str,
        ts_property_value: float,
        timestamp: datetime,
        properties: dict,
    ):
        self.entity_type_name = entity_type_name
        self.entity_instance_id = entity_instance_id
        self.entity_instance_name = entity_instance_name
        self.ts_property_name = ts_property_name
        self.ts_property_value = ts_property_value
        self.timestamp = timestamp
        self.properties = properties

    def as_dict(self):
        return {
            "entity_type_name": self.entity_type_name,
            "entity_instance_id": self.entity_instance_id,
            "entity_instance_name": self.entity_instance_name,
            "ts_property_name": self.ts_property_name,
            "ts_property_value": self.ts_property_value,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "properties": self.properties,
        }

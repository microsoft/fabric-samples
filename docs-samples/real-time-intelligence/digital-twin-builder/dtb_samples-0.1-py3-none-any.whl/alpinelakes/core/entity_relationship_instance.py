from datetime import datetime  # noqa F401
from typing import Optional


class EntityRelationshipInstance:
    relationship_type_name: str
    source_entity_instance_name: str
    target_entity_instance_name: str

    def __init__(self, relationship_type_name: str, source_entity_instance_name: str, target_entity_instance_name: str):
        self.relationship_type_name = relationship_type_name
        self.source_entity_instance_name = source_entity_instance_name
        self.target_entity_instance_name = target_entity_instance_name

    def as_dict(self):
        return {
            "relationship_type_name": self.relationship_type_name,
            "source_entity_instance_name": self.source_entity_instance_name,
            "target_entity_instance_name": self.target_entity_instance_name,
        }
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as stats
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

from ..core.semanticgraph import SemanticGraph
from .ontologygraph import AlpineLakesOntologyGraph


class AlpineLakesMLHelper:

    def get_ml_features(
        self,
        graph_helper: AlpineLakesOntologyGraph,
        ontology_graph: SemanticGraph,
        predict_entity: str,
        predict_entity_properties: list[str],
        feature_entities: list[str],
    ) -> pd.DataFrame:

        seed_entity = predict_entity
        seed_properties = predict_entity_properties
        linked_entities = feature_entities

        seed_entity_types = {seed_entity: []}
        seed_entity_type_list = list(seed_entity_types.keys())

        seed_entity_graph = graph_helper.search_graph(
            ontology_graph, seed_entity_type_list[0], "entity_type", seed_entity_type_list[0], 1
        ).graph
        for n, d in seed_entity_graph.nodes(data=True):
            entity_type_name = d.get("entity_type")
            if entity_type_name in seed_entity_type_list and d.get("node_type") == "ENIN":
                seed_entity_types[entity_type_name].append(d)

        # test_entity_type = seed_entity_type_list[0]
        # df = pd.DataFrame(seed_entity_types[test_entity_type])
        # display(df)

        linked_entity_types = {}
        for le in linked_entities:
            linked_entity_types[le] = []

        linked_entity_type_list = list(linked_entity_types.keys())

        for se in seed_entity_types[seed_entity_type_list[0]]:
            # print(se["DisplayName"])
            # print("-------------------------")
            current_graph = graph_helper.search_graph(
                ontology_graph, se["entity_type"], "entity_instance_id", se["entity_instance_id"], 4, ["Site"]
            ).graph
            for n, d in current_graph.nodes(data=True):
                entity_type_name = d.get("entity_type")
                if entity_type_name in linked_entities and d.get("node_type") == "ENINT" and "timestamp" in d:
                    for sp in seed_properties:
                        d[sp] = se[sp]

                    linked_entity_types[entity_type_name].append(d)

        df_return = pd.DataFrame()
        for le in linked_entity_type_list:
            df_temp = pd.DataFrame(linked_entity_types[le])
            pivot_index = ["timestamp"]
            for sp in seed_properties:
                pivot_index.append(sp)

            df = df_temp.pivot(index=pivot_index, columns="entity_ts_property", values="label")
            df = df.reset_index()
            if df_return.empty:
                df_return = df
            else:
                df_return = pd.merge(df_return, df, how="left", on=pivot_index)

        # display(df_return)
        return df_return

    def get_np_array(self, df: pd.DataFrame, properties: list[str]) -> pd.DataFrame:
        for p in properties:
            df[p] = df[p].astype(float)
            df[p] = df[p].fillna(df[p].median())

        return df[properties].to_numpy()

    def run_basic_whatif_analysis(
        self, ml_feature_df: pd.DataFrame, features, output_labels, quality_labels
    ) -> pd.DataFrame:

        # Split data into training and testing sets
        X_train, X_test, y_output_train, y_output_test = train_test_split(
            features, output_labels, test_size=0.2, random_state=42
        )
        X_train, X_test, y_quality_train, y_quality_test = train_test_split(
            features, quality_labels, test_size=0.2, random_state=42
        )

        # Train models
        output_model = RandomForestRegressor(n_estimators=100, random_state=42)
        output_model.fit(X_train, y_output_train)

        quality_model = RandomForestRegressor(n_estimators=100, random_state=42)
        quality_model.fit(X_train, y_quality_train)

        # Step 3: What-If Analysis - Simulating a New Production Run
        def simulate_production_run(feed_flow, reflux_ratio, temperature):
            prediction_input = np.array([[feed_flow, reflux_ratio, temperature]])
            predicted_output = output_model.predict(prediction_input)[0]
            predicted_quality = quality_model.predict(prediction_input)[0]
            return predicted_output, predicted_quality

        # TODO - Hardcoded for now, need to be dynamic
        feed_flow_values = np.linspace(min(ml_feature_df["FeedFlowRate"]), max(ml_feature_df["FeedFlowRate"]), 10)
        reflux_ratio_values = np.linspace(min(ml_feature_df["RefluxRatio"]), max(ml_feature_df["RefluxRatio"]), 10)
        temperature_values = np.linspace(min(ml_feature_df["Temperature"]), max(ml_feature_df["Temperature"]), 10)
        simulated_outputs = []
        simulated_qualities = []

        for flow in feed_flow_values:
            for reflux in reflux_ratio_values:
                for temp in temperature_values:
                    output, quality = simulate_production_run(feed_flow=flow, reflux_ratio=reflux, temperature=temp)
                    simulated_outputs.append(output)
                    simulated_qualities.append(quality)

        sim_data = pd.DataFrame(
            {
                "FeedFlowRate": np.tile(feed_flow_values, len(reflux_ratio_values) * 10),
                "RefluxRatio": np.repeat(reflux_ratio_values, len(feed_flow_values) * 10),
                "Temperature": np.repeat(temperature_values, len(feed_flow_values) * 10),
                "SimulatedOutput": simulated_outputs,
                "SimulatedQuality": simulated_qualities,
            }
        )

        return sim_data

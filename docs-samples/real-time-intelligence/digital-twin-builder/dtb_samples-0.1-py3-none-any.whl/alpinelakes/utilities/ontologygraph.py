import datetime
import json
import random
from typing import Optional

import networkx as nx
import numpy as np
from IPython.display import HTML, display
from networkx import MultiDiGraph
from pyvis.network import Network

from ..core import Ontology, SemanticGraph


class AlpineLakesOntologyGraph:
    ontology: Ontology
    ENTITY_TYPE_NODE = "ENTY"
    ENTITY_INSTANCE_NODE = "ENIN"
    ENTITY_INSTANCE_TIMESERIES_NODE = "ENINT"
    ENTITY_TYPE_ATTRIBUTE_NAME = "entity_type"
    NODE_TYPE_ATTRIBUTE_NAME = "node_type"

    def __init__(self, ontology: Ontology):
        self.ontology = ontology

    def generate_semantic_graph(self) -> SemanticGraph:
        if len(self.ontology.instances) == 0:
            return self.__generate_definition_graph()
        else:
            return self.__generate_instance_graph()

    def visualize_ontology_graph(self, ontology_graph: SemanticGraph) -> None:

        net = Network(directed=True, select_menu=True, filter_menu=True, notebook=True, cdn_resources="in_line")
        net.from_nx(ontology_graph.graph)
        # net.save_graph ("temporal.html")
        net.show("ontology.html")
        display(HTML(filename="ontology.html"))

    def write_graph(self, ontology_graph: SemanticGraph, path: str, namespace: str) -> None:
        # TODO -> Need to replace attributes with None or NULL value, or it will throw error
        nx.write_gexf(ontology_graph.graph, f"{path}/{namespace}.gexf")

    def read_graph(self, path: str, namespace: str) -> SemanticGraph:
        filename = f"{path}/{namespace}.gexf"  # TODO fix file path concatenation
        graph = MultiDiGraph(nx.read_gexf(filename))
        ontology_graph = SemanticGraph(graph.name)
        ontology_graph.graph = graph
        return ontology_graph

    def search_graph(
        self,
        ontology_graph: SemanticGraph,
        entity: str,
        attribute: str,
        attribute_value: str,
        depth: Optional[int] = 1,
        exclude_entity_list: Optional[list] = [],
    ) -> SemanticGraph:
        graph = ontology_graph.graph.to_undirected()
        all_nodes = graph.nodes(data=True)

        # Find nodes matching the attribute and value
        matching_nodes = {
            n
            for n, d in graph.nodes(data=True)
            if d.get(attribute) == attribute_value and d.get(self.ENTITY_TYPE_ATTRIBUTE_NAME) == entity
        }

        # Expand to include adjacent nodes within given hops
        extracted_nodes = set(matching_nodes)

        for _ in range(depth):
            neighbors = set()
            for node in extracted_nodes:
                neighbors.update(graph.neighbors(node))

            # Exclude nodes that are of type ENTITY_TYPE_NODE
            neighbors_set = {
                item
                for item in neighbors
                if all_nodes[item][self.NODE_TYPE_ATTRIBUTE_NAME] != self.ENTITY_TYPE_NODE
                and all_nodes[item][self.ENTITY_TYPE_ATTRIBUTE_NAME] not in exclude_entity_list
            }

            # Exclude nodes with same entity but different attribute value
            neighbors_set_new = set()
            for item in neighbors_set:
                if all_nodes[item][self.ENTITY_TYPE_ATTRIBUTE_NAME] == entity:
                    if all_nodes[item][attribute] == attribute_value:
                        neighbors_set_new.add(item)
                else:
                    neighbors_set_new.add(item)

            extracted_nodes.update(neighbors_set_new)

        # Create subgraph with the extracted nodes
        sub_graph = graph.subgraph(extracted_nodes).copy()

        # Format the graph for visualization
        all_nodes = sub_graph.nodes(data=True)
        entity_colors = {}

        for n in sub_graph.nodes:
            entity_type = all_nodes[n].get(self.ENTITY_TYPE_ATTRIBUTE_NAME)
            if entity_type not in entity_colors:
                entity_colors[entity_type] = self.__generate_light_color()
            all_nodes[n]["color"] = entity_colors[entity_type]

            if entity_type == entity:
                if all_nodes[n].get(attribute) == attribute_value:
                    all_nodes[n]["color"] = "lightpink"

        ontology_graph = SemanticGraph(ontology_graph.graph.name)
        ontology_graph.graph = sub_graph

        return ontology_graph

    def __generate_definition_graph(self) -> SemanticGraph:
        ontology_graph = SemanticGraph(self.ontology.namespace)

        for property in self.ontology.properties:

            ontology_graph.add_node(
                property.entitytypename,
                title=property.entitytypename,
                entity_type=property.entitytypename,
                color="lightblue",
                shape="box",
            )

            ontology_graph.add_node(
                property.id,
                label=property.name,
                entity_type=property.entitytypename,
                entity_property=property.name,
                color="lightgray",
                shape="box",
            )

            ontology_graph.add_edge(property.entitytypename, property.id, color="lightblue", arrows="none")

        for relationship in self.ontology.relationships:
            ontology_graph.add_edge(
                relationship.source, relationship.target, label=relationship.name, color="lightblue"
            )

        return ontology_graph

    def __generate_instance_graph(self) -> SemanticGraph:
        ontology_graph = SemanticGraph(self.ontology.namespace)

        all_instances = {}
        for instance in self.ontology.instances:

            # add entity type
            ontology_graph.add_node(
                instance.entity_type_name,
                node_type=self.ENTITY_TYPE_NODE,
                entity_type=instance.entity_type_name,
                color="lightpink",
                size=30,
                shape="box",
            )

            # add entity instance
            json_data = json.loads(json.dumps(instance.properties, default=self.__serialize_datetime))
            ontology_graph.add_node(
                instance.entity_instance_id,
                title=str(json_data),
                label=instance.entity_instance_name,
                node_type=self.ENTITY_INSTANCE_NODE,
                entity_type=instance.entity_type_name,
                entity_instance=instance.entity_instance_name,
                entity_instance_id=instance.entity_instance_id,
                color="lightblue",
                size=10,
                shape="box",
                **json_data,
            )

            all_instances[instance.entity_instance_id] = 1
            ontology_graph.add_edge(
                instance.entity_type_name, instance.entity_instance_id, label="instance", color="gray", arrows="none"
            )

        for instance_ts_property in list(
            set(
                [
                    f"{p.entity_instance_id}#{p.ts_property_name}#{p.entity_type_name}"
                    for p in self.ontology.instances_time_series
                ]
            )
        ):

            # add entity instance timeseries
            ts_entity_instance_id = instance_ts_property.split("#")[0]
            ts_property_name = instance_ts_property.split("#")[1]
            entity_type_name = instance_ts_property.split("#")[2]
            ontology_graph.add_node(
                instance_ts_property,
                label=ts_property_name,
                title=ts_property_name,
                node_type=self.ENTITY_INSTANCE_TIMESERIES_NODE,
                entity_type=entity_type_name,
                entity_instance=ts_entity_instance_id,
                entity_ts_property=ts_property_name,
                color="lightgreen",
                size=10,
                shape="box",
            )

            ontology_graph.add_edge(
                ts_entity_instance_id, instance_ts_property, label="timeseries", color="gray", arrows="none"
            )

        for instance_ts in self.ontology.instances_time_series:

            ts = instance_ts.timestamp.isoformat()
            ts_node_id = f"{instance_ts.entity_instance_id}#{instance_ts.ts_property_name}#{instance_ts.entity_type_name}"  # must be same as instance_ts_property
            ts_value_node_id = f"{instance_ts.ts_property_name}#{ts}#{instance_ts.ts_property_value}"

            ontology_graph.add_node(
                ts_value_node_id,
                label=str(instance_ts.ts_property_value),
                title=f"{str(instance_ts.ts_property_value)} - {ts}",
                node_type=self.ENTITY_INSTANCE_TIMESERIES_NODE,
                entity_type=instance_ts.entity_type_name,
                entity_instance=instance_ts.entity_instance_id,
                entity_ts_property=instance_ts.ts_property_name,
                timestamp=ts,
                color="lightgreen",
                size=10,
            )

            ontology_graph.add_edge(ts_node_id, ts_value_node_id, label="measurement", color="gray", arrows="none")

        for rel_instance in self.ontology.relationship_instances:
            if (
                all_instances.get(rel_instance.source_entity_instance_name) == None
                or all_instances.get(rel_instance.target_entity_instance_name) == None
            ):
                continue
            ontology_graph.add_edge(
                rel_instance.source_entity_instance_name,
                rel_instance.target_entity_instance_name,
                label=rel_instance.relationship_type_name,
                color="lightpink",
                arrows="none",
            )

        return ontology_graph

    def __serialize_datetime(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()
        raise TypeError("Type not serializable")

    def __generate_light_color(self):
        r = random.randint(128, 255)
        g = random.randint(128, 255)
        b = random.randint(128, 255)
        return "#{:02x}{:02x}{:02x}".format(r, g, b)

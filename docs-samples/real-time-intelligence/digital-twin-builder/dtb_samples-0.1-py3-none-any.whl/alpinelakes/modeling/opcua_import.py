import xml.etree.ElementTree as ET 
from ..core import EntityRelationship, EntityType, EntityTypeProperty, Ontology

class OPCUAImport:

    def generate_ontology(self, xml_file_content: str, namespace_files: dict = None) -> Ontology:
        """
        Builds an Ontology object from OPC UA XML content.
        :param xml_file_content: OPC UA companion spec content as a string.
        :param namespace_files: A dictionary mapping NamespaceUri to their corresponding XML file content.
        :return: Ontology object with the main namespace
        """
        # Parse the XML content
        root = ET.fromstring(xml_file_content)

        # Determine if the XML uses a default namespace
        ns = {}
        if root.tag.startswith("{"):
            ns_uri = root.tag.split("}")[0].strip("{")
            ns = {"ns": ns_uri}

        # Extract all namespace URIs
        namespace_uris = []
        namespace_uri_elements = root.findall(".//ns:NamespaceUris/ns:Uri", ns) if ns else root.findall(".//NamespaceUris/Uri")
        for uri_elem in namespace_uri_elements:
            if uri_elem.text:
                namespace_uris.append(uri_elem.text.strip())

        if not namespace_uris:
            raise ValueError("No NamespaceUris found in the XML file.")

        # Create the main ontology with the first namespace (index 0)
        main_ontology = Ontology(namespace=namespace_uris[0])

        # Process the main XML content into the main ontology
        self._process_xml_content(root, main_ontology, ns)

        # Process dependent ontologies if provided
        if namespace_files:
            for index, uri in enumerate(namespace_uris):
                # Skip the first namespace as it's already processed
                if index == 0:
                    continue
                    
                # Check if we have content for this namespace
                if uri in namespace_files:
                    dependent_xml_content = namespace_files[uri]
                    dependent_ontology = self._process_dependent_ontology(dependent_xml_content, uri)
                    
                    # Merge the dependent ontology into the main one if needed
                    # Commented out as per requirement to keep separate ontologies
                    # main_ontology.merge(dependent_ontology)

        return main_ontology

    def generate_ontologies(self, xml_file_content: str, namespace_files: dict = None) -> list:
        """
        Builds a list of Ontology objects, one for each namespace URI.
        :param xml_file_content: OPC UA companion spec content as a string.
        :param namespace_files: A dictionary mapping NamespaceUri to their corresponding XML file content.
        :return: List of Ontology objects
        """
        # Parse the XML content
        root = ET.fromstring(xml_file_content)

        # Determine if the XML uses a default namespace
        ns = {}
        if root.tag.startswith("{"):
            ns_uri = root.tag.split("}")[0].strip("{")
            ns = {"ns": ns_uri}

        # Extract all namespace URIs
        namespace_uris = []
        namespace_uri_elements = root.findall(".//ns:NamespaceUris/ns:Uri", ns) if ns else root.findall(".//NamespaceUris/Uri")
        for uri_elem in namespace_uri_elements:
            if uri_elem.text:
                namespace_uris.append(uri_elem.text.strip())

        if not namespace_uris:
            raise ValueError("No NamespaceUris found in the XML file.")

        ontologies = []

        # Create the main ontology with the first namespace (index 0)
        main_ontology = Ontology(namespace=namespace_uris[0])
        self._process_xml_content(root, main_ontology, ns)
        ontologies.append(main_ontology)

        # Process dependent ontologies if provided
        if namespace_files:
            for index, uri in enumerate(namespace_uris):
                # Skip the first namespace as it's already processed
                if index == 0:
                    continue
                    
                # Check if we have content for this namespace
                if uri in namespace_files:
                    dependent_xml_content = namespace_files[uri]
                    dependent_ontology = self._process_dependent_ontology(dependent_xml_content, uri)
                    ontologies.append(dependent_ontology)

        return ontologies

    def _process_dependent_ontology(self, xml_content, namespace_uri):
        """
        Process dependent ontology from XML content.
        :param xml_content: XML content for the dependent ontology.
        :param namespace_uri: Namespace URI for this ontology.
        :return: Processed Ontology object
        """
        dependent_root = ET.fromstring(xml_content)
        
        # Create ontology for this namespace
        dependent_ontology = Ontology(namespace=namespace_uri)
        
        # Determine if dependent XML uses a default namespace
        dep_ns = {}
        if dependent_root.tag.startswith("{"):
            dep_ns_uri = dependent_root.tag.split("}")[0].strip("{")
            dep_ns = {"ns": dep_ns_uri}
        
        # Process the dependent XML content
        self._process_xml_content(dependent_root, dependent_ontology, dep_ns)
        
        return dependent_ontology

    def _process_xml_content(self, root, ontology, ns):
        """
        Process the XML content and populate the ontology.
        :param root: XML root element
        :param ontology: Ontology object to populate
        :param ns: Namespace dictionary
        """
        # Extract object types, variable types, and reference types
        if ns:
            object_types = root.findall(".//ns:UAObjectType", ns)
            variable_types = root.findall(".//ns:UAVariableType", ns)
            reference_types = root.findall(".//ns:UAReferenceType", ns)
        else:
            object_types = root.findall(".//UAObjectType")
            variable_types = root.findall(".//UAVariableType")
            reference_types = root.findall(".//UAReferenceType")

        # Process object types
        for ua_object_type in object_types:
            entity_type = EntityType(
                id=ua_object_type.get("NodeId"),
                name=ua_object_type.get("BrowseName"),
                description=(
                    ua_object_type.findtext(".//ns:Description", default="", namespaces=ns)
                    if ns
                    else ua_object_type.findtext(".//Description", default="")
                ),
                namespace=ontology.namespace,
                isreadonly=False,
            )
            setattr(entity_type, "parent_node_id", ua_object_type.get("ParentNodeId", ""))
            ontology.add_entity_type(entity_type)

        # Process variable types
        for ua_variable_type in variable_types:
            entity_property = EntityTypeProperty(
                id=ua_variable_type.get("NodeId"),
                name=ua_variable_type.get("BrowseName"),
                description=(
                    ua_variable_type.findtext(".//ns:Description", default="", namespaces=ns)
                    if ns
                    else ua_variable_type.findtext(".//Description", default="")
                ),
                datatype=ua_variable_type.get("DataType"),
                entitytypeid=ua_variable_type.get("ParentNodeId", ""),
                namespace=ontology.namespace,
            )
            ontology.add_entity_property(entity_property)

        # Process references
        for ua_object_type in object_types:
            references_elem = ua_object_type.find("ns:References", ns) if ns else ua_object_type.find("References")
            if references_elem is not None:
                ref_elements = (
                    references_elem.findall("ns:Reference", ns) if ns else references_elem.findall("Reference")
                )
                for ref in ref_elements:
                    ref_type = ref.get("ReferenceType", "")
                    is_forward = ref.get("IsForward", "true").lower()
                    target_node = ref.text.strip() if ref.text else ""
                    source_node = ua_object_type.get("NodeId")
                    if is_forward == "false":
                        source_node, target_node = target_node, source_node

                    entity_relationship = EntityRelationship(
                        name=ref_type, source=source_node, target=target_node, namespace=ontology.namespace
                    )
                    ontology.add_entity_relationship(entity_relationship)
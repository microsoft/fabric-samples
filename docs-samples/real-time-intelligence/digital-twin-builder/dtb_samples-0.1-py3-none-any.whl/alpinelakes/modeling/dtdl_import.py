import json
import logging
from typing import Dict, List, Set

from dtb.core import EntityRelationship, EntityType, EntityTypeProperty, Ontology


class DTDLImport:
    def __init__(self):
        self.entity_types_map = {}

    """
    Callouts:
        1. In the case of a missing parent, i.e., extends references a non-existence type, no properties/relationships will be inherited. Ontology will be instantialized, no error message thrown.
        2. In the case of a circular reference, i.e., A extends B and B extends A, no properties/relationships will be inherited. Ontology will be instantiated, no error message thrown.
    """

    def generate_ontology(self, namespace: str, dtdl_file_content: str) -> Ontology:
        ontology = Ontology(namespace)

        try:
            dtdl_data = self._parse_dtdl_content(dtdl_file_content)

            # First, process all entity types
            self._process_entity_types(dtdl_data, ontology, namespace)

            # Then, process properties and relationships
            self._process_properties_and_relationships(dtdl_data, ontology, namespace)

            # Finally, apply full inheritance
            self._apply_full_inheritance(ontology, namespace)
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            logging.error(f"Error parsing DTDL content: {e}")
            raise ValueError(f"Error parsing DTDL content: {e}")

        return ontology

    def _parse_dtdl_content(self, dtdl_file_content: str) -> List[Dict]:
        dtdl_data = json.loads(dtdl_file_content)
        if isinstance(dtdl_data, dict):
            dtdl_data = [dtdl_data]
        return dtdl_data

    def _process_entity_types(self, dtdl_data: List[Dict], ontology: Ontology, namespace: str) -> None:
        for dt_definition in dtdl_data:
            if not isinstance(dt_definition, dict):
                raise ValueError(f"Expected a dictionary, got {type(dt_definition)}: {dt_definition}")

            if dt_definition["@type"] == "Interface":
                # Handle single or multiple inheritance
                parent_ids = dt_definition.get("extends", [])
                if isinstance(parent_ids, str):
                    parent_ids = [parent_ids]

                entity_type = EntityType(
                    id=dt_definition.get("@id", ""),
                    name=dt_definition["displayName"],
                    description=dt_definition.get("description", ""),
                    namespace=namespace,
                    isreadonly=dt_definition.get("isreadonly", False),
                    parententitytypeid=parent_ids[0] if parent_ids else "",  # Set first parent for compatibility
                )
                # Store ALL parent IDs as an attribute
                entity_type.all_parent_ids = parent_ids
                ontology.add_entity_type(entity_type)
                self.entity_types_map[entity_type.id] = entity_type

    def _process_properties_and_relationships(self, dtdl_data: List[Dict], ontology: Ontology, namespace: str) -> None:
        for dt_definition in dtdl_data:
            if dt_definition["@type"] == "Interface":
                entity_id = dt_definition.get("@id", "")

                if "contents" in dt_definition:
                    for content in dt_definition["contents"]:
                        if content["@type"] == "Property":
                            entity_property = EntityTypeProperty(
                                id=content.get("@id", ""),
                                name=content["name"],
                                description=content.get("description", ""),
                                datatype=content["schema"],
                                entitytypeid=entity_id,
                                namespace=namespace,
                            )
                            ontology.add_entity_property(entity_property)

                        elif content["@type"] == "Relationship":
                            entity_relationship = EntityRelationship(
                                name=content["name"],
                                source=entity_id,
                                target=content["target"],
                                namespace=namespace,
                            )
                            ontology.add_entity_relationship(entity_relationship)

    def _apply_full_inheritance(self, ontology: Ontology, namespace: str) -> None:
        # Collect all inherited properties for a given entity type
        def collect_inherited_properties(entity_type, visited=None):
            if visited is None:
                visited = set()

            # Prevent infinite recursion
            if entity_type.id in visited:
                return []
            visited.add(entity_type.id)

            # Collect properties for this entity type
            inherited_properties = []

            # Get all parent IDs (use all_parent_ids if available)
            parent_ids = getattr(entity_type, "all_parent_ids", [])

            # Collect properties from ALL parent types
            for parent_id in parent_ids:
                # Find parent entity type
                parent_entity = next((et for et in ontology.types if et.id == parent_id), None)
                if not parent_entity:
                    continue

                # Collect properties of this parent
                parent_properties = [prop for prop in ontology.properties if prop.entitytypeid == parent_id]
                inherited_properties.extend(parent_properties)

                # Recursively collect from grandparent types
                inherited_properties.extend(collect_inherited_properties(parent_entity, visited))

            return inherited_properties

        # Apply inherited properties to each entity type
        for entity_type in ontology.types:
            # Skip if not a derived type
            if not hasattr(entity_type, "all_parent_ids") or not entity_type.all_parent_ids:
                continue

            # Collect inherited properties
            inherited_props = collect_inherited_properties(entity_type)

            # Add inherited properties that are not already present
            for prop in inherited_props:
                existing_prop = next(
                    (
                        existing
                        for existing in ontology.properties
                        if existing.name == prop.name and existing.entitytypeid == entity_type.id
                    ),
                    None,
                )

                if not existing_prop:
                    inherited_prop = EntityTypeProperty(
                        id=f"{prop.id}_inherited",
                        name=prop.name,
                        description=prop.description,
                        datatype=prop.datatype,
                        entitytypeid=entity_type.id,
                        namespace=namespace,
                    )
                    ontology.add_entity_property(inherited_prop)

    @classmethod
    def test_import(cls, sample_dtdl_content: str = None):
        # Configure logging
        logging.basicConfig(level=logging.INFO)

        # Use provided content or create a default sample
        if sample_dtdl_content is None:
            sample_dtdl_content = json.dumps(
                [
                    {
                        "@id": "dtmi:test:EntityA;1",
                        "@type": "Interface",
                        "displayName": "EntityA",
                        "extends": "dtmi:test:EntityB;1",
                        "contents": [],
                    },
                    {
                        "@id": "dtmi:test:EntityB;1",
                        "@type": "Interface",
                        "displayName": "EntityB",
                        "extends": "dtmi:test:EntityA;1",
                        "contents": [],
                    },
                ]
            )

        try:
            # Create an instance and generate ontology
            dtdl_importer = cls()
            ontology = dtdl_importer.generate_ontology(
                namespace="test_namespace", dtdl_file_content=sample_dtdl_content
            )

            # Print out the generated ontology details
            print("Entity Types:")
            for entity_type in ontology.types:
                print(f"- {entity_type.name} (ID: {entity_type.id})")

            print("\nProperties:")
            for prop in ontology.properties:
                print(f"- {prop.name} (Type: {prop.datatype}, Entity Type: {prop.entitytypeid})")

            print("\nRelationships:")
            for rel in ontology.relationships:
                print(f"- {rel.name} (Source: {rel.source}, Target: {rel.target})")

            return ontology

        except Exception as e:
            logging.error(f"Error during ontology generation: {e}")
            raise


# Allow direct script execution for testing
if __name__ == "__main__":
    DTDLImport.test_import()

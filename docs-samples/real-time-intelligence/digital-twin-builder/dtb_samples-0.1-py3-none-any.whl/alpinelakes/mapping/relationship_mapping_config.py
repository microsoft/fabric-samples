class RelationshipMappingConfig:
    source_entity_name: str
    target_entity_name: str
    source_entity_property: str
    target_entity_property: str

    def __init__(
        self,
        source_entity_name: str,
        target_entity_name: str,
        source_entity_property: str,
        target_entity_property: str
    ):
        self.source_entity_name = source_entity_name
        self.target_entity_name = target_entity_name
        self.source_entity_property = source_entity_property
        self.target_entity_property = target_entity_property
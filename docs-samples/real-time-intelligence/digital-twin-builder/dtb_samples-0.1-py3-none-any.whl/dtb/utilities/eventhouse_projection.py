import re
from typing import List, Optional

from pyspark.sql import DataFrameReader, SparkSession

from ..client import DtbClient
from ..core import (
    EntityInstance,
    EntityInstanceTimeSeries,
    EntityRelationship,
    EntityRelationshipInstance,
    EntityType,
    EntityTypeProperty,
    Ontology,
)


class DtbEventhouseHelper:
    client: DtbClient

    kql_function_name_token = "#function_name#"
    kql_function_entitytypeid_token = "#function_entitytypeid#"
    kql_function_columns_token = "#function_columns#"
    kql_property_function_template = """.create-or-alter function #function_name# () {
        let entity_property = (
            external_table("propertydescriptor")
            | where EntityTypeId == '#function_entitytypeid#'
            | project PropertyDescriptorId = Id, Name, ValueTypeId
            | join kind=leftouter (
                (external_table("stringpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, StringValue = Value)
                | union (external_table("boolpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, BoolValue = Value)
                | union (external_table("bigintpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, BigIntValue = Value)
                | union (external_table("doublepropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, DoubleValue = Value)
                | union (external_table("floatpropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, FloatValue = Value)
                | union (external_table("datetimepropertyvalue")
                | where isnull(ValidTo)
                | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, DateTimeValue = Value)
            ) on PropertyDescriptorId
            | project EntityInstanceId1, EntityInstanceId2, PropertyDescriptorId, Name, StringValue, BoolValue, BigIntValue, DoubleValue, FloatValue, DateTimeValue
            | where isnotnull(EntityInstanceId1) and isnotnull(EntityInstanceId2)
            | summarize
                #function_columns#
        );
        entity_property
        }
    """

    kql_ts_function_template = """.create-or-alter function #function_name# () {
        let Timeseries_property = (
            external_table("timeseriespropertydescriptor")
            | where EntityTypeId == '#function_entitytypeid#'
            | project TimeseriesPropertyDescriptorId = Id, Name, ValueTypeId
            | join kind=inner (
                external_table("timeseriesinstancedescriptor")
                | project Id1, Id2, EntityInstanceId1, EntityInstanceId2, TimeseriesPropertyDescriptorId
            ) on $left.TimeseriesPropertyDescriptorId == $right.TimeseriesPropertyDescriptorId
            | join kind=leftouter (
                (external_table("stringtimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, StringValue = Value)
                | union (external_table("booltimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, BoolValue = Value)
                | union (external_table("biginttimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, BigIntValue = Value)
                | union (external_table("floattimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, FloatValue = Value)
                | union (external_table("doubletimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, DoubleValue = Value)
                | union (external_table("datetimetimeseriesvalue")
                | project TimeseriesInstanceDescriptorId1, TimeseriesInstanceDescriptorId2, PreciseTimestamp, DateTimeValue = Value)
            ) on $left.Id1 == $right.TimeseriesInstanceDescriptorId1 and $left.Id2 == $right.TimeseriesInstanceDescriptorId2
            | project EntityInstanceId1, EntityInstanceId2, PreciseTimestamp, Name, StringValue, BoolValue, BigIntValue, DoubleValue, FloatValue, DateTimeValue
            | where isnotnull(EntityInstanceId1) and isnotnull(EntityInstanceId2)
            | summarize
                #function_columns#
        );
        Timeseries_property
        }
    """

    kql_shortcut_table_name_token = "#table_name#"
    kql_shortcut_base_path_token = "#base_path#"
    kql_create_shortcut_template = """.create-or-alter external table #table_name#
    kind=delta
    (  
        h@'#base_path#.Lakehouse/Tables/#table_name#;impersonate'
    )
    //.alter external table #table_name# policy query_acceleration '{ "IsEnabled": true, "Hot": "36500d" }'
    """

    def __init__(self, client: DtbClient):
        self.client = client

    def generate_eventhouse_projection(
        self, current_ontology_lh_name: str, spark: SparkSession, df_reader: DataFrameReader
    ) -> str:

        valuetypes = {}
        valuetypes["bigint"] = "BigIntValue"
        valuetypes["varchar"] = "StringValue"
        valuetypes["bit"] = "BoolValue"
        valuetypes["float"] = "DoubleValue"
        valuetypes["datetime2"] = "DateTimeValue"

        file_content = """
                .execute database script with (ContinueOnErrors=true)
                <|
                """

        view_definition_query = "SELECT TABLE_NAME, VIEW_DEFINITION FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_SCHEMA = 'dom' AND TABLE_NAME != 'relationships'"
        df_views_schema = df_reader.synapsesql(view_definition_query)
        # views_def_list = df_views_schema.rdd.map(lambda x: x[1]).collect()

        for viewdefrow in df_views_schema.rdd.toLocalIterator():
            entity_function_name = viewdefrow["TABLE_NAME"]
            entity_type_id = 0
            match = re.search(r"EntityTypeId\s*=\s*'(\d+)'", viewdefrow["VIEW_DEFINITION"])
            if match:
                entity_type_id = match.group(1)

            # print(f"{entity_function_name} -> {entity_type_id}")

            property_query = f"SELECT COLUMN_NAME,DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{entity_function_name}'"
            df_property = df_reader.synapsesql(property_query)
            function_column_text = ""
            for property_row in df_property.rdd.toLocalIterator():
                if ("EntityInstanceId" in property_row["COLUMN_NAME"]) or (property_row["COLUMN_NAME"] == "Timestamp"):
                    continue

                function_column_text += f'{property_row["COLUMN_NAME"]} = minif({valuetypes[property_row["DATA_TYPE"]]}, Name == "{property_row["COLUMN_NAME"]}"),'

            function_column_text = function_column_text[:-1]
            current_function_template = ""
            if "_property" in entity_function_name:
                function_column_text += " by EntityInstanceId1, EntityInstanceId2 "
                current_function_template = self.kql_property_function_template
            else:
                function_column_text += " by EntityInstanceId1, EntityInstanceId2, PreciseTimestamp "
                current_function_template = self.kql_ts_function_template

            function_text = (
                current_function_template.replace(self.kql_function_name_token, entity_function_name)
                .replace(self.kql_function_entitytypeid_token, str(entity_type_id))
                .replace(self.kql_function_columns_token, function_column_text)
            )
            file_content += function_text

            print(f"Added function - {entity_function_name}")

        return file_content

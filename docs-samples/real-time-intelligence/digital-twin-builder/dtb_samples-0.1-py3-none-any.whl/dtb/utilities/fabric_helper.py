from typing import List, Optional

from pyspark.sql import DataFrameReader, SparkSession

from ..client import DtbClient
from ..core import (
    EntityInstance,
    EntityInstanceTimeSeries,
    EntityRelationship,
    EntityRelationshipInstance,
    EntityType,
    EntityTypeProperty,
    Ontology,
)
from .eventhouse_projection import DtbEventhouseHelper


# Merge these methods into DtbClient once we have stable way to access data from Fabric Lakehouse and SQL Endpoint
class DtbFabricHelper:
    client: DtbClient

    def __init__(self, client: DtbClient):
        self.client = client

    def get_ontology_data(
        self,
        spark: SparkSession,
        df_reader: DataFrameReader,
        include_instances: Optional[bool] = False,
        max_instances_per_entity: Optional[int] = 10,
        max_timeseries_per_instance: Optional[int] = 10,
    ) -> Ontology:
        if include_instances:
            return self.__get_ontology_instance(spark, df_reader, max_instances_per_entity, max_timeseries_per_instance)
        else:
            return self.__get_ontology_definition(spark)

    def __get_ontology_definition(self, spark: SparkSession) -> Ontology:
        namespace = self.client.config.item_name
        current_ontology = Ontology(namespace)
        current_ontology_lh_name = (
            self.client.config.item_name + "dtdm"
        )  # self.client.config.lakehouse_absf_path.split("/")[-1].split(".")[0]

        df_types = (
            spark.read.synapsesql(f"{current_ontology_lh_name}.dbo.entitytype")
            .filter("BaseEntityTypeId != 0")
            .withColumnRenamed("Name", "EntityTypeName")
        )
        df_types_relationships = spark.read.synapsesql(
            f"{current_ontology_lh_name}.dbo.entitytyperelationship"
        ).withColumnRenamed("Name", "RelationshipName")
        df_types_properties = spark.read.synapsesql(
            f"{current_ontology_lh_name}.dbo.propertydescriptor"
        ).withColumnRenamed("Name", "PropertyName")

        df_properties = df_types.join(df_types_properties, df_types.Id == df_types_properties.EntityTypeId).select(
            df_types["EntityTypeName"], df_types["Id"], df_types_properties["PropertyName"]
        )

        for row in df_properties.rdd.toLocalIterator():
            typeId = row["EntityTypeName"]
            typeName = row["EntityTypeName"]
            propertyName = row["PropertyName"]
            propertyId = typeName + "_" + propertyName
            current_entity_type = EntityType(typeId, typeName, typeName, namespace)
            current_property = EntityTypeProperty(
                propertyId, propertyName, propertyName, "TODO", typeId, namespace, typeName
            )
            current_ontology.add_entity_type(current_entity_type)
            current_ontology.add_entity_property(current_property)

        joindf_r1 = (
            df_types.join(df_types_relationships, df_types.Id == df_types_relationships.FirstEntityTypeId)
            .select(
                df_types["EntityTypeName"],
                df_types_relationships["RelationshipName"],
                df_types_relationships["SecondEntityTypeId"],
            )
            .withColumnRenamed("EntityTypeName", "FirstEntityTypeName")
        )

        df_relationships = (
            joindf_r1.join(df_types, joindf_r1.SecondEntityTypeId == df_types.Id)
            .select(joindf_r1["FirstEntityTypeName"], joindf_r1["RelationshipName"], df_types["EntityTypeName"])
            .withColumnRenamed("EntityTypeName", "SecondEntityTypeName")
        )

        for row in df_relationships.rdd.toLocalIterator():
            current_relationship = EntityRelationship(
                row["RelationshipName"], row["FirstEntityTypeName"], row["SecondEntityTypeName"]
            )
            current_ontology.add_entity_relationship(current_relationship)

        return current_ontology

    def __get_entity_instance_timeseries(
        self,
        typeName: str,
        current_ontology_lh_name: str,
        df_reader: DataFrameReader,
        entity_instance_id_1: int,
        entity_instance_id_2: int,
        entity_instance_name: str,
        max_timeseries_per_instance: int,
    ) -> List[EntityInstanceTimeSeries]:

        entity_instance_ts = []

        try:
            ts_view_name = typeName + "_timeseries"
            ts_query = (
                f"SELECT TOP {max_timeseries_per_instance} * FROM {current_ontology_lh_name}.dom.{ts_view_name} "
                "WHERE EntityInstanceId1 is not NULL "
                f"AND EntityInstanceId1 = {entity_instance_id_1} "
                f"AND EntityInstanceId2 = {entity_instance_id_2} "
                "ORDER BY Timestamp desc"
            )
            df_view_ts = df_reader.synapsesql(ts_query)
            exclude_columns = ["EntityInstanceId1", "EntityInstanceId2", "PreciseTimestamp", "Timestamp"]
            ts_columns = list(set(df_view_ts.columns) - set(exclude_columns))
            for instance_row_ts in df_view_ts.rdd.toLocalIterator():  # Need to make this parallel execution
                ts_instance_id = (
                    str(instance_row_ts["EntityInstanceId1"]) + "_" + str(instance_row_ts["EntityInstanceId2"])
                )  # not a good way to generate identifier
                timestamp = instance_row_ts["Timestamp"]
                for tsc in ts_columns:
                    ts_property_name = tsc
                    ts_property_value = instance_row_ts[tsc]
                    # print(f"{ts_instance_id} - {timestamp} - {ts_property_name} - {ts_property_value}")
                    ts_instance_displayName = f"{ts_property_name}_{str(timestamp)}"
                    ts_current_instance = EntityInstanceTimeSeries(
                        typeName,
                        ts_instance_id,
                        entity_instance_name,
                        ts_property_name,
                        ts_property_value,
                        timestamp,
                        {},
                    )
                    entity_instance_ts.append(ts_current_instance)
        except Exception as te:
            print("No timeseries data found")
            return None

        return entity_instance_ts

    def __get_ontology_instance(
        self,
        spark: SparkSession,
        df_reader: DataFrameReader,
        max_instances_per_entity: int,
        max_timeseries_per_instance: int,
    ) -> Ontology:
        namespace = self.client.config.item_name
        current_ontology = Ontology(namespace)
        current_ontology_lh_name = (
            self.client.config.item_name + "dtdm"
        )  # self.client.config.lakehouse_absf_path.split("/")[-1].split(".")[0]

        df_types = (
            spark.read.synapsesql(f"{current_ontology_lh_name}.dbo.entitytype")
            .filter("BaseEntityTypeId != 0")
            .withColumnRenamed("Name", "EntityTypeName")
        )

        df_types_collect = df_types.rdd.toLocalIterator()  # Need to make this parallel execution
        for type_row in df_types_collect:
            typeName = type_row["EntityTypeName"]
            print(f"Adding instances and timeseries for {typeName}...")

            try:
                #####  Add Instances  ####
                view_name = typeName + "_property"
                has_timeseries = True
                df_view = df_reader.synapsesql(
                    f"SELECT TOP {max_instances_per_entity} * FROM {current_ontology_lh_name}.dom.{view_name}"
                )
                # df_view_details = df_view.withColumn("json", f.to_json(f.struct(df_view.columns)))
                for instance_row in df_view.rdd.toLocalIterator():
                    entity_instance_id_1 = instance_row["EntityInstanceId1"]
                    entity_instance_id_2 = instance_row["EntityInstanceId2"]
                    instance_id = (
                        str(instance_row["EntityInstanceId1"]) + "_" + str(instance_row["EntityInstanceId2"])
                    )  # not a good way to generate identifier
                    instance_displayName = instance_row["DisplayName"]
                    current_instance = EntityInstance(
                        typeName, instance_id, instance_displayName, instance_row.asDict()
                    )
                    current_ontology.add_entity_instance(current_instance)

                    if has_timeseries:
                        tslist = self.__get_entity_instance_timeseries(
                            typeName,
                            current_ontology_lh_name,
                            df_reader,
                            instance_row["EntityInstanceId1"],
                            instance_row["EntityInstanceId2"],
                            instance_displayName,
                            max_timeseries_per_instance,
                        )

                        if tslist is None:
                            has_timeseries = False
                        else:
                            current_ontology.add_entity_instance_time_series_list(tslist)

                print(f"Added instances and timeseries for {typeName}")
                print("--------------------------------------")

            except Exception as e:
                # print(e)
                print("Something went wrong while fetching instances")
                print("--------------------------------------")

        df_relationships_view = df_reader.synapsesql(f"SELECT * FROM {current_ontology_lh_name}.dom.relationships")

        df_rel_collect = df_relationships_view.rdd.toLocalIterator()
        for rel_row in df_rel_collect:
            source_instance_id = (
                str(rel_row["FirstEntityInstanceId1"]) + "_" + str(rel_row["FirstEntityInstanceId2"])
            )  # not a good way to generate identifier
            target_instance_id = (
                str(rel_row["SecondEntityInstanceId1"]) + "_" + str(rel_row["SecondEntityInstanceId2"])
            )  # not a good way to generate identifier
            relationship_name = rel_row["RelationshipName"]
            current_rel_instance = EntityRelationshipInstance(relationship_name, source_instance_id, target_instance_id)
            current_ontology.add_entity_relationship_instance(current_rel_instance)

        return current_ontology

    def generate_eventhouse_projection(self, spark: SparkSession, df_reader: DataFrameReader) -> str:
        current_ontology_lh_name = self.client.lakehouse_name
        eh_helper = DtbEventhouseHelper(self.client)
        return eh_helper.generate_eventhouse_projection(current_ontology_lh_name, spark, df_reader)

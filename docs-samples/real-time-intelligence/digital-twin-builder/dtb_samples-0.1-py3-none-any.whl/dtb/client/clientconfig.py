# from notebookutils import mssparkutils
from typing import Optional


class DtbClientConfig:

    item_name: str
    lakehouse_absf_path: str

    def __init__(self, item_name: str, workspace_name: Optional[str] = "", lakehouse_absf_path: Optional[str] = ""):
        self.item_name = item_name
        self.lakehouse_absf_path = lakehouse_absf_path
        self.workspace_name = workspace_name

    # def __init__(self, dtb: str):
    #     self.item_name = dtb_item_name

    #     # TODO -> Need to be implement
    #     # lakehouse_name = item_name + "dtdm"
    #     # lh = notebookutils.lakehouse.get(lakehouse_name)
    #     # lakehouse_absf_path = lh["properties"]["abfsPath"]

    #     # TODO -> Need to input workspace details for cross workspace access

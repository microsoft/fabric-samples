# Introduction 

This is a sample repo that being used part of the Fabric CI/CD Tutorial using the Fabric Bulk Import Item definitions API.

Full tutorial can be found [here](https://learn.microsoft.com/en-us/fabric/cicd/tutorial-bulkapi-cicd).
